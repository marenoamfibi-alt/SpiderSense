# Spider Sense 0.2.1 — Minecraft 1.21.11 (Fabric)

Client-side mod prototype for threat detection and visual alerts.

## Current features in source
- Detects hostile mobs within 16 blocks.
- Red glowing outline and floating `!` marker for detected threats.
- HUD danger accents, low-health red edges, and regeneration green edges.
- Lightweight cyan-white END_ROD sparks with occasional electric sparks while threats are nearby.
- Mod icon and metadata for the Fabric Mods list.

## Build status
This is a **source project**, not an installable mod JAR. It has not yet been compiled or tested in Minecraft. Build it in an online environment with Java 21 and Gradle, then verify the resulting JAR before installing it in Zalith Launcher.

## Build
Run `gradle build` from the project root. The JAR should be produced under `build/libs/`.
