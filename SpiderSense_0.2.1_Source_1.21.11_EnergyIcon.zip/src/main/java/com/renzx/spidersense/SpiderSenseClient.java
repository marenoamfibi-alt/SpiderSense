package com.renzx.spidersense;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.Team;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/** Client-only Spider Sense HUD prototype. Target: Minecraft 1.21.11 + Fabric. */
public final class SpiderSenseClient implements ClientModInitializer {
    private static final double DETECTION_RANGE = 16.0;
    private static final List<HostileEntity> THREATS = new ArrayList<>();
    private static int alertLevel;
    private static int lowHealthLevel;
    private static int regenerationLevel;
    private static final String THREAT_TEAM_NAME = "spidersense_threats";
    private static final Map<UUID, HostileEntity> PREVIOUS_THREATS = new LinkedHashMap<>();

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(SpiderSenseClient::tick);
        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> renderHud(drawContext));
        WorldRenderEvents.AFTER_ENTITIES.register(SpiderSenseClient::renderThreatMarkers);
    }

    private static void tick(MinecraftClient client) {
        if (client.player == null || client.world == null) {
            clearThreatOutlines();
            THREATS.clear();
            alertLevel = lowHealthLevel = regenerationLevel = 0;
            return;
        }

        var player = client.player;
        Box scanBox = player.getBoundingBox().expand(DETECTION_RANGE);
        THREATS.clear();
        THREATS.addAll(client.world.getEntitiesByClass(HostileEntity.class, scanBox,
                mob -> mob.isAlive() && player.squaredDistanceTo(mob) <= DETECTION_RANGE * DETECTION_RANGE));
        updateThreatOutlines(client.world.getScoreboard());
        spawnSenseEnergy(client);

        // Smoothly ramp up and down to avoid flickering when a mob crosses the radius.
        int targetAlert = THREATS.isEmpty() ? 0 : 170;
        alertLevel = approach(alertLevel, targetAlert, THREATS.isEmpty() ? 5 : 12);

        int targetLowHealth = player.getHealth() <= 4.0F ? 100 : 0; // <= 2 hearts
        lowHealthLevel = approach(lowHealthLevel, targetLowHealth, targetLowHealth > 0 ? 8 : 5);

        int targetRegeneration = player.hasStatusEffect(StatusEffects.REGENERATION) ? 55 : 0;
        regenerationLevel = approach(regenerationLevel, targetRegeneration, targetRegeneration > 0 ? 5 : 4);
    }


    /** Emits a few cyan-white sparks around the player while danger is nearby. */
    private static void spawnSenseEnergy(MinecraftClient client) {
        if (THREATS.isEmpty() || client.player == null || client.world == null) return;
        var player = client.player;
        // Keep the effect light: only two small particles per tick, close to the player's body.
        for (int i = 0; i < 2; i++) {
            double angle = (client.world.getTime() * 0.22) + (i * Math.PI);
            double radius = 0.42 + (i * 0.12);
            double x = player.getX() + Math.cos(angle) * radius;
            double y = player.getY() + 0.35 + ((client.world.getTime() + i * 3) % 12) * 0.12;
            double z = player.getZ() + Math.sin(angle) * radius;
            client.world.addParticle(ParticleTypes.END_ROD, x, y, z,
                    Math.cos(angle) * 0.012, 0.018, Math.sin(angle) * 0.012);
        }
        // Occasional electric sparks add a brief danger-flash accent.
        if (client.world.getTime() % 7 == 0) {
            client.world.addParticle(ParticleTypes.ELECTRIC_SPARK,
                    player.getX(), player.getY() + 0.9, player.getZ(), 0.0, 0.025, 0.0);
        }
    }

    /** Adds a floating red exclamation mark above each currently detected hostile. */
    private static void renderThreatMarkers(net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;

        MatrixStack matrices = context.matrixStack();
        VertexConsumerProvider consumers = context.consumers();
        if (matrices == null || consumers == null) return;

        var cameraPos = context.camera().getPos();
        for (HostileEntity mob : THREATS) {
            if (!mob.isAlive() || mob.getWorld() != client.world) continue;

            double x = mob.getX() - cameraPos.x;
            double y = mob.getY() + mob.getHeight() + 0.35 - cameraPos.y;
            double z = mob.getZ() - cameraPos.z;

            matrices.push();
            matrices.translate(x, y, z);
            matrices.multiply(context.camera().getRotation());
            matrices.scale(-0.025F, -0.025F, 0.025F);

            String marker = "!";
            float textWidth = client.textRenderer.getWidth(marker);
            client.textRenderer.draw(
                    marker, -textWidth / 2.0F, 0.0F, 0xFFFF3030, false,
                    matrices.peek().getPositionMatrix(), consumers,
                    net.minecraft.client.font.TextRenderer.TextLayerType.SEE_THROUGH,
                    0, LightmapTextureManager.MAX_LIGHT_COORDINATE
            );
            matrices.pop();
        }
    }

    /** Applies red glowing outlines to detected hostiles and removes our outline when they leave range. */
    private static void updateThreatOutlines(Scoreboard scoreboard) {
        Team team = scoreboard.getTeam(THREAT_TEAM_NAME);
        if (team == null) {
            team = scoreboard.addTeam(THREAT_TEAM_NAME);
            team.setColor(Formatting.RED);
        }

        Map<UUID, HostileEntity> current = new LinkedHashMap<>();
        for (HostileEntity mob : THREATS) {
            current.put(mob.getUuid(), mob);
            mob.setGlowing(true);
            scoreboard.addScoreHolderToTeam(mob.getUuidAsString(), team);
        }

        for (Map.Entry<UUID, HostileEntity> entry : PREVIOUS_THREATS.entrySet()) {
            if (!current.containsKey(entry.getKey())) {
                HostileEntity oldMob = entry.getValue();
                if (oldMob.isGlowing()) oldMob.setGlowing(false);
                scoreboard.removeScoreHolderFromTeam(oldMob.getUuidAsString(), team);
            }
        }
        PREVIOUS_THREATS.clear();
        PREVIOUS_THREATS.putAll(current);
    }

    private static void clearThreatOutlines() {
        for (HostileEntity mob : PREVIOUS_THREATS.values()) {
            if (mob.isGlowing()) mob.setGlowing(false);
            if (mob.getWorld() != null) {
                Team team = mob.getWorld().getScoreboard().getTeam(THREAT_TEAM_NAME);
                if (team != null) {
                    mob.getWorld().getScoreboard().removeScoreHolderFromTeam(mob.getUuidAsString(), team);
                }
            }
        }
        PREVIOUS_THREATS.clear();
    }

    private static int approach(int current, int target, int step) {
        if (current < target) return Math.min(target, current + step);
        if (current > target) return Math.max(target, current - step);
        return current;
    }

    private static void renderHud(DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;

        int width = context.getScaledWindowWidth();
        int height = context.getScaledWindowHeight();
        boolean minimal = client.world.getRegistryKey() == World.NETHER || client.world.getRegistryKey() == World.END;

        if (alertLevel > 0 && !THREATS.isEmpty()) {
            int red = (alertLevel << 24) | 0x00FF3030;
            if (minimal) {
                context.drawText(client.textRenderer, "!", width - 14, 10, red, true);
                // Minimal Sense: thin edge accents instead of a full comic frame.
                drawEdges(context, width, height, 1, red);
            } else {
                drawComicRays(context, width, height, red);
                context.drawText(client.textRenderer, "!", width / 2 - 3, 12, red, true);
            }
        }

        if (lowHealthLevel > 0) {
            int redVignette = (lowHealthLevel << 24) | 0x00E52222;
            drawEdges(context, width, height, 3, redVignette);
        }
        if (regenerationLevel > 0) {
            int greenTint = (regenerationLevel << 24) | 0x0035D66F;
            // Keep regeneration subtle, and let low-health red remain visually dominant.
            drawEdges(context, width, height, lowHealthLevel > 0 ? 1 : 2, greenTint);
        }
    }

    private static void drawEdges(DrawContext context, int width, int height, int thickness, int color) {
        context.fill(0, 0, width, thickness, color);
        context.fill(0, height - thickness, width, height, color);
        context.fill(0, 0, thickness, height, color);
        context.fill(width - thickness, 0, width, height, color);
    }

    private static void drawComicRays(DrawContext context, int width, int height, int color) {
        drawEdges(context, width, height, 2, color);
        int ray = Math.max(8, Math.min(width, height) / 18);
        // Short diagonal-ish comic accents built from small rectangles, no textures required.
        context.fill(8, 8, 8 + ray, 10, color);
        context.fill(8, 8, 10, 8 + ray, color);
        context.fill(width - 8 - ray, 8, width - 8, 10, color);
        context.fill(width - 10, 8, width - 8, 8 + ray, color);
        context.fill(8, height - 10, 8 + ray, height - 8, color);
        context.fill(width - 8 - ray, height - 10, width - 8, height - 8, color);
    }
}
